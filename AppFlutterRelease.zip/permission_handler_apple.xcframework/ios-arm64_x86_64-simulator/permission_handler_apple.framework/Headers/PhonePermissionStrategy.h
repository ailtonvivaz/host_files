//
//  PhonePermissionStrategy.h
//  permission_handler
//
//  Created by Sebastian Roth on 5/20/19.
//

#import <Foundation/Foundation.h>
#import "PermissionStrategy.h"

NS_ASSUME_NONNULL_BEGIN

@interface PhonePermissionStrategy : NSObject<PermissionStrategy>

@end

NS_ASSUME_NONNULL_END
